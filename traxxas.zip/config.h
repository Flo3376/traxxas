#ifndef CONFIG_H
#define CONFIG_H

// Configuration Wi-Fi : Définir le SSID et le mot de passe
#define WIFI_SSID "Redmi Note 13 Pro 5G"
#define WIFI_PASSWORD "uheku675"

// Configuration mDNS : Nom unique pour découvrir l'ESP sur le réseau
//#define MDNS_NAME "bobinette_the_esp_killeuse"

// Configuration IP statique (si nécessaire)
//#define WIFI_STATIC_IP IPAddress(192, 168, 127, 100)
//#define WIFI_GATEWAY IPAddress(192, 168, 127, 1)
//#define WIFI_SUBNET IPAddress(255, 255, 255, 0)

#endif
